package com.example.parcialahora;

public interface FormaCalcularSalario {
    public double calcularSalario();
}
